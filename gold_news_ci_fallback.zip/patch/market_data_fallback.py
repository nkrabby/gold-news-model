"""Anonymous Yahoo Finance intraday fallback for Dukascopy WAF failures.

Gold uses COMEX continuous futures (GC=F), not spot XAUUSD. The fallback is
intentionally explicit so dashboard users can see the source-regime transition.
"""
from __future__ import annotations

import requests
import pandas as pd

URL = "https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"


def yahoo_bars(symbol: str, interval: str = "60m", period: str = "60d") -> pd.DataFrame:
    """Fetch a public Yahoo chart interval and return Dukascopy-compatible columns."""
    response = requests.get(
        URL.format(symbol=symbol),
        params={"range": period, "interval": interval},
        headers={"User-Agent": "Mozilla/5.0"},
        timeout=30,
    )
    response.raise_for_status()
    chart = response.json().get("chart", {})
    if chart.get("error") or not chart.get("result"):
        raise RuntimeError(f"Yahoo returned no data for {symbol}: {chart.get('error')}")
    result = chart["result"][0]
    quotes = result["indicators"]["quote"][0]
    frame = pd.DataFrame({
        "timestamp": [int(t) * 1000 for t in result["timestamp"]],
        "open": quotes.get("open"),
        "high": quotes.get("high"),
        "low": quotes.get("low"),
        "close": quotes.get("close"),
        "volume": quotes.get("volume"),
    })
    frame = frame.dropna(subset=["close"]).sort_values("timestamp")
    if frame.empty:
        raise RuntimeError(f"Yahoo returned an empty price series for {symbol}")
    return frame


def continuous_merge(old: pd.DataFrame | None, fresh: pd.DataFrame) -> pd.DataFrame:
    """Join a new provider's series to stored history with overlap level-alignment."""
    fresh = fresh.copy()
    if old is None or old.empty:
        return fresh.drop_duplicates("timestamp", keep="last").sort_values("timestamp")

    old = old.copy()
    old["timestamp"] = pd.to_numeric(old["timestamp"], errors="coerce")
    fresh["timestamp"] = pd.to_numeric(fresh["timestamp"], errors="coerce")
    overlap = old[["timestamp", "close"]].dropna().merge(
        fresh[["timestamp", "close"]].dropna(), on="timestamp", suffixes=("_old", "_new")
    )
    if not overlap.empty:
        anchor = overlap.sort_values("timestamp").iloc[-1]
        factor = float(anchor.close_old / anchor.close_new)
    else:
        # If markets had no exact shared candle, align the new first close to the
        # final stored close; this avoids a spurious provider-basis jump.
        p_old = float(old.dropna(subset=["close"]).sort_values("timestamp").iloc[-1].close)
        p_new = float(fresh.dropna(subset=["close"]).sort_values("timestamp").iloc[0].close)
        factor = p_old / p_new

    for col in ("open", "high", "low", "close"):
        if col in fresh:
            fresh[col] = pd.to_numeric(fresh[col], errors="coerce") * factor
    merged = pd.concat([old, fresh], ignore_index=True)
    return merged.drop_duplicates("timestamp", keep="last").sort_values("timestamp").reset_index(drop=True)
